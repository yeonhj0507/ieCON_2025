import zipfile
import pandas as pd

def evaluate(user_submission_file,
             phase_codename,
             test_annotation_file=None,
             **kwargs):
    """
    single-phase 챌린지용 evaluate():
     - test_annotation_file: annotations.zip (demand_eval_filtered.csv, demand_test_filtered.csv)
     - user_submission_file: 참가자 제출 CSV
     - **kwargs: submission_metadata 등(무시해도 됨)
    """

    # 1) 제출값 로드
    sub = pd.read_csv(user_submission_file)

    # 2) ZIP에서 두 개의 CSV 읽기
    with zipfile.ZipFile(test_annotation_file, 'r') as z:
        gt_val  = pd.read_csv(z.open("demand_eval_filtered.csv"))
        gt_test = pd.read_csv(z.open("demand_test_filtered.csv"))

    # 3) WAPE 계산 함수
    def _wape(gt_df):
        merged = gt_df.merge(sub, on=["date","sku","warehouse"])
        if merged.empty:
            return 9999.0
        abs_err = (merged["demand"] - merged["mean"]).abs().sum()
        total   = merged["demand"].sum()
        return (abs_err / total * 100) if total != 0 else float("inf")

    wape_val  = round(_wape(gt_val),  4)
    wape_test = round(_wape(gt_test), 4)

    # 4) EvalAI 리턴 포맷 (한 phase로 두 split 메트릭 모두 반환)
    return {
        "result": [
            {"val_split":  {"WAPE_Public":  wape_val}},
            {"test_split": {"WAPE_Private": wape_test}}
        ],
        "submission_result": {
            "WAPE_Public":  wape_val,
            "WAPE_Private": wape_test
        }
    }
